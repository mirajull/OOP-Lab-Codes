package util;

import java.io.Serializable;

public class Data  implements Serializable {
    
     public String info;
     
     public Data(String information){
         info=information;
     }
    
}
